//
//  LevelManager.h
//  Rocky
//
//  Created by Tuyuer on 13-2-3.
//
//

#ifndef __Rocky__LevelManager__
#define __Rocky__LevelManager__

#include <iostream>
#include "cocos2d.h"

class LevelManager :public cocos2d::CCObject{
public:
    static LevelManager * create();
};

#endif /* defined(__Rocky__LevelManager__) */
